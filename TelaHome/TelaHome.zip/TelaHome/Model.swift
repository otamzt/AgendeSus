//
//  Model.swift
//  TelaHome
//
//  Created by Turma02-10 on 28/02/25.
//

import Foundation

struct NewsItem: Hashable{
    let link: String
    let imageURL: String
}

