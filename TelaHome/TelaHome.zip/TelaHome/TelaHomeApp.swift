//
//  TelaHomeApp.swift
//  TelaHome
//
//  Created by Turma02-10 on 27/02/25.
//

import SwiftUI

@main
struct TelaHomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
